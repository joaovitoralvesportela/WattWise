package application;


import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.application.Application;

public class Main extends Application {

	@Override
	public void start(Stage janelaide) throws Exception {
		
		Parent root = FXMLLoader.load(getClass().getResource("/application/tela_ide.fxml")); 
		Scene cena = new Scene(root, 1600, 900);
		
		janelaide.setScene(cena);
		janelaide.setTitle("Homeride - Gerenciando seu aluguel");
		janelaide.setResizable(false);
		janelaide.setMaximized(false);
		janelaide.show();
	}
	
	public static void main(String[] args) {
		launch(args);

	}

}
