package application;

import javafx.fxml.FXML;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class tela_controle_ide {

    @FXML
    private Font x1;

    @FXML
    private Color x2;

}
