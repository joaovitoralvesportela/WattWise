
/*
|================================================================|
|  CLASSE PARA O BANCO DE DADOS DO SISTEMA WitteWise             |       
|================================================================|
*/


package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

// Banco de dados relacionado ao sistema WitteWise


public class BancoDeDados {
    private Connection connection = null;

    // Método para conectar ao banco
    public void conectar() {
        // Substitua 'nome_do_banco' pelo nome real do seu banco no MySQL
        String servidor = "jdbc:mysql://localhost:3306/wattwise"; // precisa informar o servidor do banco de dados para ele se conectar a ele
        String usuario = "root";
        String senha = "Senac";
        String driver = "com.mysql.cj.jdbc.Driver";

        try {
            Class.forName(driver);
            this.connection = DriverManager.getConnection(servidor, usuario, senha);
        } catch (Exception e) {
            System.out.println("Erro ao conectar ao banco: " + e.getMessage());
        }
    }

    // Método para verificar se está conectado
    public boolean estarConectado() {
        try {
            return this.connection != null && !this.connection.isClosed();
        } catch (Exception e) {
            return false;
        }
    }

    // Método para desconectar
    public void desconectar() {
        try {
            if (this.connection != null && !this.connection.isClosed()) {
                this.connection.close();
            }
        } catch (Exception e) {
            System.out.println("Erro ao desconectar: " + e.getMessage());
        }
    }
    // Esse metodo será utilizado para inserir contas na classe tela_controle_cadastro
    // Método para inserir contas (Cadastro)
    public boolean inserirContas(String nome, String email, String senha, String data_nascimento) {
        // DICA: Lembre-se de criptografar a 'senha' antes de enviar para o banco!
        String query = "INSERT INTO NomeDaTabela (nome, email, senha, data_nascimento) VALUES (?, ?, ?, ?)";

        try (PreparedStatement pstmt = this.connection.prepareStatement(query)) {
            pstmt.setString(1, nome);
            pstmt.setString(2, email);
            pstmt.setString(3, senha);
            pstmt.setString(4, data_nascimento);
            pstmt.executeUpdate();
            return true; // Cadastro realizado com sucesso
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar: " + e.getMessage());
            return false; // Falha no cadastro (ex: e-mail duplicado)
        }
    }

    // Função para validar login
    // Essa função será utilizada para a validar o login na classe tela_controle_cadastro
    public boolean validaLogin(String email, String senha) {
        String query = "SELECT * FROM NomeDaTabela WHERE email = ? AND senha = ?";

        try (PreparedStatement pstmt = this.connection.prepareStatement(query)) {
            pstmt.setString(1, email);
            pstmt.setString(2, senha);

            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next(); // Retorna true se encontrou o usuário
            }

        } catch (Exception e) {
            System.out.println("Erro ao validar login: " + e.getMessage());
            return false;
        }
    }
    // Criar funções par inserir o restante das informações. Como equipamentos e etc
    
}

/*
-> Codigo do banco de dados:

create database wattwise;
use wattwise;

create table usuarios(
id int auto_increment primary key,
nome varchar(255) not null,
email varchar(255) not null,
senha_hash varchar (255) not null,
data_cadastro date not null
);

create table equipamentos(
id int auto_increment primary key,
id_usuario int not null,
nome varchar(255) not null,
potencia_w numeric(10,2) not null,www
horas_uso_dia numeric(5,2) not null,
dias_uso_mes smallint not null,
ativo boolean not null default true,
data_cadastro date not null
);

create table registros(
id int auto_increment primary key,
id_usuario int not null,
data_inicio date not null,
data_fim date not null,
consumo_kwh numeric(10,3) not null,
data_cadastro datetime default current_timestamp
);

create table tarifas (
id int auto_increment primary key,
id_usuario int not null,
valor_kwh numeric(10,5) not null,
data_inicio date not null,
data_fim date,
data_cadastro datetime default current_timestamp
);

create table itens_consumo (
id_registro int not null,
id_equipamento int not null,
consumo_kwh numeric(10,3) not null,
primary key (id_registro, id_equipamento),
foreign key (id_registro) references registros(id),
foreign key (id_equipamento) references equipamentos(id)
);

select * from usuarios;
select * from equipamentos;
select * from registros;
select * from itens_consumo;
select * from tarifas;



*/